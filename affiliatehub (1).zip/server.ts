import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import axios from 'axios';
import * as cheerio from 'cheerio';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Helper to extract keywords and host from a URL when scraping fails
function extractUrlClues(urlStr: string) {
  try {
    const parsed = new URL(urlStr);
    const domain = parsed.hostname.replace('www.', '');
    // Clean path name: split by slashes, dashes, underscores
    const pathParts = parsed.pathname.split('/')
      .filter(p => p.length > 1)
      .map(p => p.replace(/[-_]/g, ' '))
      // Filter out long alphanumeric hashes of 10+ chars (potential IDs)
      .filter(p => !/^[a-z0-9]{10,}$/i.test(p))
      // Filter out standard non-semantic path elements
      .filter(p => !/^(dp|gp|ref|product|item|show|watch|p|product-reviews)$/i.test(p));
    
    const urlClues = pathParts.join(' ').trim();
    return { domain, urlClues: urlClues || parsed.pathname };
  } catch (e) {
    return { domain: '', urlClues: '' };
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post('/api/process-link', async (req, res) => {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL is required' });

    let rawTitle = '';
    let rawDescription = '';
    let imageUrl = '';
    let price = '';
    let scrapeStatus = 'success';
    let scrapeWarning = '';

    // 1. Attempt Scraping metadata with rich browser-like headers
    try {
      const response = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Referer': 'https://www.google.com/',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive'
        },
        timeout: 8000
      });
      const $ = cheerio.load(response.data);
      
      rawTitle = $('meta[property="og:title"]').attr('content') || $('title').text() || '';
      rawDescription = $('meta[property="og:description"]').attr('content') || $('meta[name="description"]').attr('content') || '';
      imageUrl = $('meta[property="og:image"]').attr('content') || '';
      price = $('meta[property="product:price:amount"]').attr('content') || 
                  $('meta[property="og:price:amount"]').attr('content') || 
                  $('.price').first().text().trim() || '';

      // Clean up relative image paths
      if (imageUrl && imageUrl.startsWith('/') && !imageUrl.startsWith('//')) {
        try {
          const parsedUrl = new URL(url);
          imageUrl = `${parsedUrl.protocol}//${parsedUrl.host}${imageUrl}`;
        } catch (_) {}
      } else if (imageUrl && imageUrl.startsWith('//')) {
        imageUrl = `https:${imageUrl}`;
      }
    } catch (error: any) {
      scrapeStatus = 'failed';
      scrapeWarning = error.message || 'Scraping blocked by target website privacy server or anti-bot rules.';
      console.warn(`Scraping warning on URL "${url}":`, scrapeWarning);
    }

    // Try finding or resolving a fallback image if no valid absolute image was scraped
    if (!imageUrl || imageUrl.trim() === '') {
      // Premium placeholder with beautiful store concept matches any e-commerce product
      imageUrl = 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?q=80&w=800';
    }

    const { domain, urlClues } = extractUrlClues(url);

    let finalTitle = '';
    let finalDescription = '';
    let finalTags: string[] = [];
    let isOfflineFallbackUsed = false;

    try {
      // 2. Modern @google/genai Integration using non-deprecated gemini-3.5-flash
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY environment variable is not defined.');
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const prompt = `
        Act as a professional affiliate marketer, SEO writer, and creative copywriter. 
        I have scraped the metadata from a product link to optimize:
        
        URL: ${url}
        Derived Domain: ${domain}
        URL Clues: ${urlClues}
        Scraped Info:
        - Raw Title: ${rawTitle || 'Not available'}
        - Raw Description: ${rawDescription || 'Not available'}
        - Detected Price: ${price || 'Not available'}
        
        Scraping Status: ${scrapeStatus}
        ${scrapeWarning ? `Scrape Warning: ${scrapeWarning}` : ''}

        Your Task:
        Generate highly engaging, conversion-optimized, professional marketing assets:
        1. An ultra-engaging, click-worthy Title (max 60 chars).
        2. A persuasive, SEO-friendly Description (max 160 chars) focused on hooks, features, or product benefits.
        3. A list of 3 to 5 highly relevant product tag names (e.g. "Smartphones" or "Deals" - simple text without '#' symbols).

        IMPORTANT: If the Scraping Status is 'failed', you must reconstruct what the product is by leveraging the URL Clues and Domain, and make your best educated guess of the brand and product type to generate an amazing creative title and description! Do not mention the scrape failure to the user.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: "The optimized affiliate/product title (max 60 chars)."
              },
              description: {
                type: Type.STRING,
                description: "The high-conversion product description (max 160 chars)."
              },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "List of 3 to 5 relevant tag names."
              }
            },
            required: ["title", "description", "tags"]
          }
        }
      });

      const responseText = response.text || '';
      let aiData = { title: '', description: '', tags: [] as string[] };
      try {
        aiData = JSON.parse(responseText.trim());
      } catch (err) {
        // Cleaning markdown wrappers if somehow returned
        const cleanedText = responseText.replace(/```json|```/gi, '').trim();
        aiData = JSON.parse(cleanedText);
      }

      finalTitle = aiData.title;
      finalDescription = aiData.description;
      finalTags = aiData.tags;

    } catch (error: any) {
      console.warn('API call failed; falling back to offline optimization model rules:', error.message || error);
      isOfflineFallbackUsed = true;

      // Clean & compile best guess Title offline
      let titleGuess = rawTitle ? rawTitle.trim() : '';
      if (!titleGuess && urlClues) {
        titleGuess = urlClues.split(' ')
          .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1))
          .join(' ');
      }
      if (!titleGuess) {
        titleGuess = 'Premium Product Deal';
      }

      // Strip common store badges/suffixes
      titleGuess = titleGuess.replace(/\s*[|•-]\s*(Amazon|eBay|Myntra|Flipkart|Walmart|AliExpress|Shopify|Store|E-commerce).*/gi, '');
      if (titleGuess.length > 55) {
        titleGuess = titleGuess.substring(0, 52) + '...';
      }

      finalTitle = `Featured: ${titleGuess}`;

      // Build compelling Description hook
      const domainCap = domain ? domain.charAt(0).toUpperCase() + domain.slice(1) : 'Select Store';
      finalDescription = rawDescription ? rawDescription.trim() : `Incredible deal on this outstanding product from ${domainCap}. Top performance, high-quality craft design, and excellent pricing. Check options now!`;
      if (finalDescription.length > 155) {
        finalDescription = finalDescription.substring(0, 152) + '...';
      }

      // Generate smart Tags from text clues offline
      const cluesLower = urlClues.toLowerCase();
      const detectedTags: string[] = [];
      if (cluesLower.includes('phone') || cluesLower.includes('tech') || cluesLower.includes('device') || cluesLower.includes('game') || cluesLower.includes('audio') || cluesLower.includes('camera') || cluesLower.includes('laptop')) {
        detectedTags.push('Electronics', 'Gadgets');
      }
      if (cluesLower.includes('shoe') || cluesLower.includes('shirt') || cluesLower.includes('pant') || cluesLower.includes('jacket') || cluesLower.includes('wear') || cluesLower.includes('dress') || cluesLower.includes('cloth')) {
        detectedTags.push('Fashion', 'Apparel');
      }
      if (cluesLower.includes('home') || cluesLower.includes('kitchen') || cluesLower.includes('decor') || cluesLower.includes('furniture')) {
        detectedTags.push('Home Living', 'HomeDecor');
      }
      if (domain) {
        detectedTags.push(domainCap);
      }
      detectedTags.push('Deals', 'Trending');
      
      finalTags = Array.from(new Set(detectedTags)).slice(0, 4);
    }

    res.json({
      title: finalTitle || 'Special Offer Product',
      description: finalDescription || 'Check out this amazing find! Click to view details, price, and specs.',
      tags: finalTags && finalTags.length > 0 ? finalTags : ['Affiliate', 'Deals', 'Trending'],
      imageUrl,
      originalUrl: url,
      rawTitle: rawTitle || urlClues || 'Product Meta',
      price: price || 'View on Store',
      _fallback: isOfflineFallbackUsed
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
