/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Feed from './components/Feed';
import CreatePost from './components/CreatePost';
import Profile from './components/Profile';

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Router>
      <Layout onSearch={setSearchTerm}>
        <Routes>
          <Route path="/" element={<Feed searchTerm={searchTerm} />} />
          <Route path="/create" element={<CreatePost />} />
          <Route path="/edit/:id" element={<CreatePost />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </Layout>
    </Router>
  );
}
