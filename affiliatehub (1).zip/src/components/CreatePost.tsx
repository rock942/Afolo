import React, { useState, useEffect } from 'react';
import { Wand2, Link as LinkIcon, Image as ImageIcon, Check, Loader2, Sparkles, ArrowRight, ArrowLeft, Type, Hash, Globe, Upload } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import axios from 'axios';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, doc, getDoc, updateDoc } from 'firebase/firestore';
import { useNavigate, useParams } from 'react-router-dom';
import { cn } from '../lib/utils';

type Step = 'source' | 'processing' | 'verify' | 'refine' | 'visuals' | 'publish';

export default function CreatePost() {
  const { id } = useParams();
  const [step, setStep] = useState<Step>(id ? 'refine' : 'source');
  const [url, setUrl] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const fetchPost = async () => {
        try {
          const postRef = doc(db, 'posts', id);
          const snap = await getDoc(postRef);
          if (snap.exists()) {
            const data = snap.data();
            setResult(data);
            setUrl(data.originalUrl || '');
            setStep('refine');
          } else {
            navigate('/create');
          }
        } catch (err) {
          console.error("Error fetching post data:", err);
          navigate('/create');
        }
      };
      fetchPost();
    } else {
      // Clear state for new post creation
      setStep('source');
      setUrl('');
      setResult(null);
      setError('');
    }
  }, [id, navigate]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setResult((prev: any) => ({ ...prev, imageUrl: e.target?.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleProcess = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!url) return;
    
    setStep('processing');
    setError('');
    
    try {
      const response = await axios.post('/api/process-link', { url });
      setResult(response.data);
      setStep('verify');
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.error || 'Failed to process link');
      setStep('source');
    }
  };

  const handlePublish = async () => {
    if (!auth.currentUser || !result) return;
    const path = id ? `posts/${id}` : 'posts';

    try {
      if (id) {
        await updateDoc(doc(db, 'posts', id), {
          title: result.title,
          description: result.description,
          tags: result.tags,
          imageUrl: result.imageUrl,
          updatedAt: new Date().toISOString()
        });
      } else {
        await addDoc(collection(db, 'posts'), {
          userId: auth.currentUser.uid,
          user: {
            displayName: auth.currentUser.displayName,
            photoURL: auth.currentUser.photoURL
          },
          title: result.title,
          description: result.description,
          tags: result.tags,
          imageUrl: result.imageUrl,
          originalUrl: result.originalUrl,
          clicks: 0,
          likesCount: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
      navigate('/');
    } catch (err) {
      handleFirestoreError(err, id ? OperationType.UPDATE : OperationType.CREATE, path);
    }
  };

  const steps = [
    { id: 'source', label: 'Source', icon: LinkIcon },
    { id: 'verify', label: 'Verify', icon: Globe },
    { id: 'refine', label: 'Content', icon: Type },
    { id: 'visuals', label: 'Visuals', icon: ImageIcon },
    { id: 'publish', label: 'Review', icon: Check },
  ];

  const currentStepIndex = steps.findIndex(s => s.id === (step === 'processing' ? 'source' : step));

  return (
    <div id="create-post-container" className="max-w-4xl mx-auto py-8">
      {/* Progress Stepper */}
      <div id="progress-stepper-track" className="flex items-center justify-between mb-16 relative">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/5 -translate-y-1/2 z-0" />
        <div 
          id="progress-stepper-fill"
          className="absolute top-1/2 left-0 h-0.5 bg-indigo-500 -translate-y-1/2 z-0 transition-all duration-500" 
          style={{ width: `${(currentStepIndex / (steps.length - 1)) * 100}%` }}
        />
        
        {steps.map((s, i) => {
          const Icon = s.icon;
          const isActive = i <= currentStepIndex;
          const isCurrent = i === currentStepIndex;
          
          return (
            <div key={s.id} id={`stepper-node-${s.id}`} className="relative z-10 flex flex-col items-center gap-3">
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 border-2",
                isCurrent ? "bg-indigo-600 border-indigo-400 scale-110 shadow-lg shadow-indigo-500/20" : 
                isActive ? "bg-indigo-600/20 border-indigo-500/50" : "bg-brand-bg border-white/10"
              )}>
                <Icon className={cn("w-5 h-5", isActive ? "text-white" : "text-slate-600")} />
              </div>
              <span className={cn(
                "text-[10px] font-bold uppercase tracking-widest transition-colors duration-500",
                isActive ? "text-indigo-400" : "text-slate-600"
              )}>
                {s.label}
              </span>
            </div>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        {step === 'source' && (
          <motion.div
            key="source"
            id="source-step-container"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-xl mx-auto text-center"
          >
            <div className="mb-10">
              <div className="w-20 h-20 bg-indigo-600/10 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Globe className="w-10 h-10 text-indigo-500" />
              </div>
              <h1 className="text-4xl font-display font-black mb-4">Start with a Link</h1>
              <p className="text-slate-400">Paste your affiliate URL and we'll handle the rest using AI.</p>
            </div>

            <form onSubmit={handleProcess} className="space-y-6">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-focus-within:opacity-100" />
                <div className="relative glass-card border-none overflow-hidden">
                  <LinkIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-500" />
                  <input
                    id="source-url-input"
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://amazon.com/product/..."
                    className="w-full bg-transparent py-6 pl-14 pr-6 focus:outline-none text-lg font-medium placeholder:text-slate-600"
                    required
                  />
                </div>
              </div>

              {error && <p className="text-red-400 text-sm font-medium">{error}</p>}

              <button
                id="source-submit-button"
                type="submit"
                disabled={!url}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white py-5 rounded-3xl font-black text-xl shadow-2xl shadow-indigo-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
              >
                Analyze with AI
                <ArrowRight className="w-6 h-6" />
              </button>
            </form>
          </motion.div>
        )}

        {step === 'processing' && (
          <motion.div
            key="processing"
            id="processing-step-container"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center py-20 text-center"
          >
            <div className="relative mb-10">
              <div className="w-32 h-32 border-8 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin" />
              <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 text-indigo-500 animate-pulse" />
            </div>
            <h2 className="text-3xl font-display font-bold mb-3 tracking-tight">AI is working its magic...</h2>
            <div className="flex flex-col gap-2 max-w-xs mx-auto">
              {['Scraping product metadata...', 'Analyzing consumer intent...', 'Generating catchy titles...', 'SEO optimizing descriptions...'].map((t, i) => (
                <div key={i} className="flex items-center gap-3 text-slate-500 text-sm">
                  <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" style={{ animationDelay: `${i * 300}ms` }} />
                  {t}
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {step === 'verify' && (
          <motion.div
            key="verify"
            id="verify-step-container"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-2xl mx-auto space-y-8"
          >
            <div className="text-center">
              <h3 className="text-3xl font-display font-black mb-2">Identify Payload</h3>
              <p className="text-slate-400">Is this the product you want to promote?</p>
            </div>

            <div className="glass-card overflow-hidden">
               <div className="aspect-video relative overflow-hidden bg-white/5">
                 <img src={result?.imageUrl} className="w-full h-full object-cover" alt="" />
                 {result?.price && (
                   <div className="absolute top-4 right-4 bg-indigo-600 text-white px-4 py-2 rounded-2xl font-black text-xl shadow-xl shadow-indigo-500/20">
                     {result.price}
                   </div>
                 )}
               </div>
               <div className="p-8">
                 <h4 className="text-2xl font-display font-bold mb-4">{result?.rawTitle}</h4>
                 <div className="flex items-center gap-2 text-slate-500 text-sm mb-6 pb-6 border-b border-white/5">
                   <Globe className="w-4 h-4" />
                   <span className="truncate">{result?.originalUrl}</span>
                 </div>
                 
                 <div className="flex gap-4">
                    <button id="verify-reset-button" onClick={() => setStep('source')} className="glass-button flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2">
                       <ArrowLeft className="w-4 h-4" /> Reset
                    </button>
                    <button id="verify-optimize-button" onClick={() => setStep('refine')} className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-2xl font-black shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.98]">
                       Optimize with AI <ArrowRight className="w-4 h-4" />
                    </button>
                 </div>
               </div>
            </div>
          </motion.div>
        )}

        {step === 'refine' && (
          <motion.div
            key="refine"
            id="refine-step-container"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12"
          >
            <div className="space-y-8">
              <div>
                <h3 className="text-3xl font-display font-black mb-2">Refine Content</h3>
                <p className="text-slate-400">AI has drafted a hook. Make it yours.</p>
                {result?._fallback && (
                  <div className="mt-4 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-amber-300 text-xs leading-relaxed">
                    <span className="font-bold uppercase tracking-wider block mb-1">⚡ Heuristic Matcher Active</span>
                    An intelligent local rule engine compiled these marketing fields because your background Gemini API Key is leaked or unconfigured. The application is **100% operational**, but you can insert a healthy API Key in the settings for deep custom LLM optimization.
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <div className="glass-card p-6 border-white/5 space-y-4">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <Type className="w-3 h-3" /> Engaging Title
                  </label>
                  <input
                    id="refine-title-input"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 font-display font-bold text-2xl focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    value={result?.title}
                    onChange={(e) => setResult({ ...result, title: e.target.value })}
                  />
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold px-1">
                    <span>MAX 80 CHARS</span>
                    <span className={cn(result?.title?.length > 80 ? "text-red-500" : "")}>{result?.title?.length}/80</span>
                  </div>
                </div>

                <div className="glass-card p-6 border-white/5 space-y-4">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <Sparkles className="w-3 h-3" /> Product Story
                  </label>
                  <textarea
                    id="refine-desc-textarea"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-slate-400 min-h-[160px] focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed"
                    value={result?.description}
                    onChange={(e) => setResult({ ...result, description: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button id="refine-back-button" onClick={() => setStep(id ? 'refine' : 'verify')} className="glass-button px-8 py-4 rounded-3xl font-bold flex items-center gap-2">
                  <ArrowLeft className="w-5 h-5" /> Back
                </button>
                <button id="refine-next-button" onClick={() => setStep('visuals')} className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-3xl flex items-center justify-center gap-2 transition-all shadow-xl shadow-indigo-600/30">
                  Next Step: Visuals <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="hidden lg:block">
              <div className="sticky top-24">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 text-center">Live Preview</p>
                <div className="glass-card border-indigo-500/30 overflow-hidden shadow-2xl shadow-indigo-500/10">
                   <div className="aspect-video bg-white/5 flex items-center justify-center relative">
                     {result?.imageUrl ? (
                       <img src={result.imageUrl} className="w-full h-full object-cover" alt="" />
                     ) : (
                       <div className="flex flex-col items-center text-slate-700">
                         <ImageIcon className="w-16 h-16 mb-2" />
                         <span className="text-xs font-bold uppercase tracking-widest">No Image Yet</span>
                       </div>
                     )}
                   </div>
                   <div className="p-8 space-y-4">
                     <h4 className="text-2xl font-display font-bold leading-tight">{result?.title || 'Placeholder Title'}</h4>
                     <p className="text-slate-400 text-sm line-clamp-3 leading-relaxed">{result?.description || 'Description will appear here...'}</p>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'visuals' && (
          <motion.div
            key="visuals"
            id="visuals-step-container"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-2xl mx-auto space-y-10"
          >
            <div className="text-center">
              <h3 className="text-4xl font-display font-black mb-3">Visual Branding</h3>
              <p className="text-slate-400">Scraped image not good enough? Upload your own custom product photo or provide a URL.</p>
            </div>

            <div className="glass-card p-10 space-y-8">
              {/* Product Preview Image Block */}
              <div className="aspect-video rounded-3xl overflow-hidden border-2 border-white/5 bg-black/40 group relative shadow-inner">
                {result?.imageUrl ? (
                  <img src={result.imageUrl} className="w-full h-full object-cover" alt="Custom Product" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-slate-700">
                    <ImageIcon className="w-20 h-20 mb-2 opacity-20" />
                    <p className="font-bold uppercase tracking-widest text-xs">Awaiting Visual</p>
                  </div>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                   <span className="bg-white text-black px-4 py-2 rounded-full font-bold text-xs">Selected Product Image</span>
                </div>
              </div>

              {/* Drag-and-Drop and File Uploader Section */}
              <div className="space-y-4">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Upload Product Image</label>
                <div 
                  id="visuals-drag-drop-zone"
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  className={cn(
                    "border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center gap-3 transition-all cursor-pointer select-none",
                    dragActive ? "border-indigo-500 bg-indigo-500/10 scale-[1.02]" : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10"
                  )}
                  onClick={() => document.getElementById('visuals-file-input')?.click()}
                >
                  <div className="p-4 bg-indigo-600/10 rounded-2xl text-indigo-400">
                    <Upload className="w-8 h-8" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-slate-200">Drag and drop your image here, or <span className="text-indigo-400 hover:underline">browse</span></p>
                    <p className="text-xs text-slate-500 mt-1">Supports PNG, JPG, JPEG, GIF, and WEBP</p>
                  </div>
                  <input 
                    id="visuals-file-input" 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleFileChange} 
                  />
                </div>
              </div>

              <div className="flex items-center gap-4 text-slate-600 text-xs font-bold uppercase tracking-widest">
                <div className="flex-1 h-[1px] bg-white/5" />
                OR
                <div className="flex-1 h-[1px] bg-white/5" />
              </div>

              {/* URL input fallback */}
              <div className="space-y-4">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Paste Image URL</label>
                <div className="relative">
                  <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <input
                    id="visuals-url-input"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    placeholder="https://images.unsplash.com/photo-..."
                    value={result?.imageUrl && !result.imageUrl.startsWith('data:') ? result.imageUrl : ''}
                    onChange={(e) => setResult({ ...result, imageUrl: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <button id="visuals-back-button" onClick={() => setStep('refine')} className="glass-button px-10 py-5 rounded-3xl font-bold">
                Back
              </button>
              <button id="visuals-next-button" onClick={() => setStep('publish')} className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-indigo-600/30">
                Next: Final Review <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        )}

        {step === 'publish' && (
          <motion.div
            key="publish"
            id="publish-step-container"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto space-y-10"
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Check className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-4xl font-display font-black mb-3">Ready to Launch?</h3>
              <p className="text-slate-400">Review your optimized post before adding it to the global feed.</p>
            </div>

            <div className="glass-card overflow-hidden">
               <div className="aspect-video relative">
                 <img src={result?.imageUrl} className="w-full h-full object-cover" alt="Final Product Image" />
                 <div className="absolute bottom-6 left-6 right-6 p-6 glass-card border-white/10 bg-black/60">
                   <h4 className="text-2xl font-display font-bold mb-2">{result?.title}</h4>
                   <div className="flex flex-wrap gap-2 mb-4">
                     {result?.tags?.map((t: string) => (
                       <span key={t} className="text-[10px] font-black uppercase tracking-widest text-indigo-400">#{t}</span>
                     ))}
                   </div>
                 </div>
               </div>
               
               <div className="p-10 space-y-8">
                 <div className="space-y-4">
                   <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 flex items-center gap-2">
                     <Hash className="w-3 h-3" /> Edit Tags
                   </label>
                   <input
                     id="publish-tags-input"
                     className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500"
                     value={result?.tags?.join(', ')}
                     onChange={(e) => setResult({ ...result, tags: e.target.value.split(',').map((t: string) => t.trim()).filter(Boolean) })}
                     placeholder="tag1, tag2, tag3"
                   />
                 </div>
               </div>
            </div>

            <div className="flex gap-4">
              <button id="publish-back-button" onClick={() => setStep('visuals')} className="glass-button px-10 py-5 rounded-3xl font-bold">
                Back
              </button>
              <button id="publish-submit-button" onClick={handlePublish} className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-3xl flex items-center justify-center gap-3 transition-all shadow-2xl shadow-indigo-600/50">
                Launch to Hub <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
