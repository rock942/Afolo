import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { collection, query, where, orderBy, onSnapshot, doc, deleteDoc, getDocs, limit } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Post } from '../types';
import { BarChart3, TrendingUp, MousePointer2, Trash2, Edit3, User as UserIcon, Calendar, ArrowUpRight, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format, subDays, startOfDay, parseISO } from 'date-fns';
import { cn } from '../lib/utils';

export default function Profile() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPostAnalytics, setSelectedPostAnalytics] = useState<Post | null>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const [isChartLoading, setIsChartLoading] = useState(false);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;
    const path = 'posts';

    const q = query(
      collection(db, path),
      where('userId', '==', user.uid)
    );

    return onSnapshot(q, (snapshot) => {
      const postsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Post[];
      
      // Sort in-memory to avoid index requirement
      postsData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      
      setPosts(postsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  }, [user]);

  const fetchAnalytics = async (post: Post) => {
    setSelectedPostAnalytics(post);
    setIsChartLoading(true);
    const clickPath = `posts/${post.id}/clicks`;
    
    try {
      const q = query(collection(db, clickPath), orderBy('timestamp', 'desc'), limit(500));
      const snap = await getDocs(q);
      const clicks = snap.docs.map(d => d.data());

      // Prepare 7-day trend
      const days = Array.from({ length: 7 }, (_, i) => {
        const date = subDays(new Date(), i);
        return {
          date: format(date, 'MMM dd'),
          timestamp: startOfDay(date).getTime(),
          clicks: 0
        };
      }).reverse();

      clicks.forEach(click => {
        const clickDate = startOfDay(parseISO(click.timestamp)).getTime();
        const day = days.find(d => d.timestamp === clickDate);
        if (day) day.clicks++;
      });

      setChartData(days);
    } catch (error) {
      console.error('Analytics error:', error);
    } finally {
      setIsChartLoading(false);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    const path = `posts/${postId}`;
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const totalClicks = posts.reduce((acc, post) => acc + (post.clicks || 0), 0);
  const avgConversion = posts.length > 0 ? (totalClicks / (posts.length * 100) * 100).toFixed(1) : 0; // Mock conversion logic
  const trendingScore = posts.length > 0 ? Math.floor(Math.random() * 100) : 0;

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <UserIcon className="w-16 h-16 text-slate-700 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Sign in to view your profile</h2>
        <p className="text-slate-400">Manage your affiliate links and track your analytics.</p>
      </div>
    );
  }

  return (
    <div id="profile-container" className="space-y-12">
      {/* Header section */}
      <div id="profile-header" className="flex flex-col sm:flex-row items-center gap-6 pb-12 border-b border-white/5">
        <div id="profile-avatar-container" className="w-32 h-32 rounded-3xl overflow-hidden border-4 border-indigo-500/20 shadow-2xl shadow-indigo-500/10">
          <img id="profile-avatar-img" src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName || 'U'}&background=random`} alt={user.displayName || ''} className="w-full h-full object-cover" />
        </div>
        <div id="profile-info" className="text-center sm:text-left">
          <h1 id="profile-name" className="font-display font-black text-4xl sm:text-5xl mb-2 tracking-tight">
            {user.displayName}
          </h1>
          <div id="profile-subtitles" className="flex items-center justify-center sm:justify-start gap-4 text-slate-400">
            <span id="profile-tier-badge" className="flex items-center gap-1.5 text-sm uppercase tracking-wider font-bold text-indigo-400">
              <TrendingUp className="w-4 h-4" />
              Pro Marketer
            </span>
            <span className="w-1 h-1 bg-slate-700 rounded-full" />
            <span id="profile-joined-date" className="flex items-center gap-1.5 text-sm">
              <Calendar className="w-4 h-4" />
              Joined April 2026
            </span>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div id="stats-cards-grid" className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <motion.div id="clicks-stat-card" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-indigo-500/20 rounded-2xl">
              <MousePointer2 className="w-6 h-6 text-indigo-400" />
            </div>
            <span className="text-[10px] font-bold text-green-400 bg-green-400/10 px-2 py-1 rounded-full uppercase tracking-widest">+12%</span>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Total Clicks</p>
          <p className="text-4xl font-display font-black">{totalClicks}</p>
        </motion.div>

        <motion.div id="conversion-stat-card" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-indigo-500/20 rounded-2xl">
              <BarChart3 className="w-6 h-6 text-indigo-400" />
            </div>
            <span className="text-[10px] font-bold text-green-400 bg-green-400/10 px-2 py-1 rounded-full uppercase tracking-widest">+5.2%</span>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Conversion Rate</p>
          <p className="text-4xl font-display font-black">{avgConversion}%</p>
        </motion.div>

        <motion.div id="trending-stat-card" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }} className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-indigo-500/20 rounded-2xl">
              <TrendingUp className="w-6 h-6 text-indigo-400" />
            </div>
            <div className="flex -space-x-2">
              <div className="w-6 h-6 rounded-full bg-indigo-500 border-2 border-brand-bg" />
              <div className="w-6 h-6 rounded-full bg-slate-400 border-2 border-brand-bg" />
            </div>
          </div>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Trending Score</p>
          <p className="text-4xl font-display font-black">{trendingScore}</p>
        </motion.div>
      </div>

      {/* Analytics Visualization Module */}
      <AnimatePresence>
        {selectedPostAnalytics && (
          <motion.div
            id="analytics-visualization-panel"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card overflow-hidden border-indigo-500/30"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl border border-white/10 overflow-hidden">
                  <img src={selectedPostAnalytics.imageUrl} className="w-full h-full object-cover" alt="" />
                </div>
                <div>
                   <h3 className="font-bold text-lg leading-tight uppercase tracking-tight">{selectedPostAnalytics.title}</h3>
                   <p className="text-xs text-slate-500">7-Day Click Trend Analysis</p>
                </div>
              </div>
              <button 
                id="analytics-close-button"
                onClick={() => setSelectedPostAnalytics(null)} 
                className="p-2 hover:bg-white/5 rounded-full text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div id="analytics-chart-container" className="p-10 h-[350px] relative">
              {isChartLoading ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-10 h-10 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis 
                      dataKey="date" 
                      stroke="#475569" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false}
                    />
                    <YAxis 
                      stroke="#475569" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#1e293b', borderRadius: '12px' }}
                      itemStyle={{ color: '#6366f1', fontSize: '12px', fontWeight: 'bold' }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="clicks" 
                      stroke="#6366f1" 
                      strokeWidth={4} 
                      dot={{ fill: '#6366f1', strokeWidth: 2, r: 4 }} 
                      activeDot={{ r: 8, stroke: '#fff', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Posts Table */}
      <div id="posts-list-section" className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold text-2xl tracking-tight">Your Optimized Links</h2>
          <span id="posts-count-indicator" className="text-sm text-slate-500 font-medium">{posts.length} total posts</span>
        </div>

        <div className="space-y-4">
          {posts.map((post, index) => (
            <motion.div 
              key={post.id}
              id={`post-card-${post.id}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className={cn(
                "glass-card p-4 group flex flex-col sm:flex-row items-center gap-6 transition-all duration-300",
                selectedPostAnalytics?.id === post.id ? "bg-white/5 border-indigo-500/40" : "hover:bg-white/5"
              )}
            >
              <div className="w-24 h-16 rounded-xl overflow-hidden flex-shrink-0 relative group-hover:ring-2 ring-indigo-500/50 transition-all">
                <img src={post.imageUrl} alt="" className="w-full h-full object-cover" />
                <button 
                  id={`post-analytics-quick-trigger-${post.id}`}
                  onClick={() => fetchAnalytics(post)}
                  className="absolute inset-0 bg-indigo-600/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                >
                  <TrendingUp className="text-white w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 min-w-0 text-center sm:text-left">
                <h3 className="font-bold text-lg leading-tight truncate group-hover:text-indigo-400 transition-colors">
                  {post.title}
                </h3>
                <p className="text-sm text-slate-500 flex items-center justify-center sm:justify-start gap-1">
                  {post.originalUrl.substring(0, 40)}...
                  <ArrowUpRight className="w-3 h-3" />
                </p>
              </div>

              <div className="flex items-center gap-12 sm:gap-16 pr-4">
                <button 
                  id={`post-analytics-trigger-${post.id}`}
                  onClick={() => fetchAnalytics(post)}
                  className="text-center group-hover:scale-105 transition-transform"
                >
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-0.5">Clicks</p>
                  <p className="text-xl font-display font-bold flex items-center gap-2">
                    {post.clicks}
                    <ChevronRight className="w-4 h-4 text-slate-700" />
                  </p>
                </button>
                <div className="flex items-center gap-2 border-l border-white/5 pl-8">
                  <Link 
                    id={`post-edit-link-${post.id}`}
                    to={`/edit/${post.id}`}
                    className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-all"
                  >
                    <Edit3 className="w-5 h-5" />
                  </Link>
                  <button 
                    id={`post-delete-button-${post.id}`}
                    onClick={() => handleDelete(post.id)}
                    className="p-2 hover:bg-red-500/10 rounded-lg text-slate-400 hover:text-red-500 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          {posts.length === 0 && !loading && (
            <div id="no-posts-placeholder" className="text-center py-20 bg-white/5 rounded-3xl border border-dashed border-white/10">
              <p className="text-slate-500 font-medium">You haven't created any posts yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
