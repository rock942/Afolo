import React, { useState, useEffect } from 'react';
import { collection, doc, addDoc, deleteDoc, updateDoc, increment, onSnapshot, query, limit, setDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Post } from '../types';
import { ExternalLink, Tag, MessageCircle, Heart, Calendar, Send, Trash2, X, Sparkles } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface PostCardProps {
  post: Post;
  onDealClick: (post: Post) => void | Promise<void>;
  key?: React.Key | string;
}

interface Comment {
  id: string;
  userId: string;
  user: {
    displayName: string;
    photoURL: string;
  };
  text: string;
  createdAt: string;
}

export default function PostCard({ post, onDealClick }: PostCardProps) {
  const [hasLiked, setHasLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);

  const currentUser = auth.currentUser;

  // Real-time listener for current user's like state
  useEffect(() => {
    if (!currentUser) {
      setHasLiked(false);
      return;
    }
    const likeRef = doc(db, `posts/${post.id}/likes`, currentUser.uid);
    return onSnapshot(likeRef, (docSnap) => {
      setHasLiked(docSnap.exists());
    });
  }, [post.id, currentUser]);

  // Real-time listener for likes count & details to keep in sync
  useEffect(() => {
    const postRef = doc(db, 'posts', post.id);
    return onSnapshot(postRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setLikesCount(data.likesCount || 0);
      }
    });
  }, [post.id]);

  // Real-time listener for comments
  useEffect(() => {
    if (!showComments) return;

    const commentsRef = collection(db, `posts/${post.id}/comments`);
    const q = query(commentsRef, limit(50));

    return onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Comment[];
      
      // Sort comments by timestamp
      fetched.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      setComments(fetched);
    });
  }, [post.id, showComments]);

  const handleLikeToggle = async () => {
    if (!currentUser) {
      alert('Please Sign In to like products!');
      return;
    }

    const likeRef = doc(db, `posts/${post.id}/likes`, currentUser.uid);
    const postRef = doc(db, 'posts', post.id);

    try {
      if (hasLiked) {
        // Dislike: Delete like doc and decrement count
        await deleteDoc(likeRef);
        await updateDoc(postRef, {
          likesCount: increment(-1),
          updatedAt: new Date().toISOString()
        });
      } else {
        // Like: Create like doc and increment count
        await setDoc(likeRef, {
          likedAt: new Date().toISOString()
        });
        await updateDoc(postRef, {
          likesCount: increment(1),
          updatedAt: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !newComment.trim()) return;

    setIsSubmittingComment(true);
    const commentPath = `posts/${post.id}/comments`;

    try {
      await addDoc(collection(db, commentPath), {
        userId: currentUser.uid,
        user: {
          displayName: currentUser.displayName || 'Marketer',
          photoURL: currentUser.photoURL || `https://ui-avatars.com/api/?name=${currentUser.displayName || 'U'}&background=random`
        },
        text: newComment.trim(),
        createdAt: new Date().toISOString()
      });
      setNewComment('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, commentPath);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    const commentRef = doc(db, `posts/${post.id}/comments`, commentId);
    try {
      await deleteDoc(commentRef);
    } catch (error) {
      console.error('Error deleting comment:', error);
    }
  };

  return (
    <div id={`post-card-${post.id}`} className="glass-card overflow-hidden group flex flex-col h-full hover:border-indigo-500/30 transition-all duration-300">
      <div className="relative h-56 overflow-hidden bg-white/5">
        <img 
          src={post.imageUrl || 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?q=80&w=800'} 
          alt={post.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4">
          <div className="bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            Spotlight
          </div>
        </div>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <div className="flex items-center gap-2 mb-4">
          {post.user?.photoURL ? (
            <img src={post.user.photoURL} alt="" className="w-5 h-5 rounded-full ring-1 ring-white/20" />
          ) : (
            <div className="w-5 h-5 rounded-full bg-indigo-500" />
          )}
          <span className="text-xs text-slate-400 font-medium">{post.user?.displayName || 'Builder'}</span>
          <span className="text-[10px] text-slate-500">•</span>
          <span className="text-[10px] text-slate-500">{formatDistanceToNow(new Date(post.createdAt))} ago</span>
        </div>

        <h3 className="font-display font-semibold text-lg leading-tight mb-2 group-hover:text-indigo-400 transition-colors">
          {post.title}
        </h3>
        
        <p className="text-slate-400 text-sm line-clamp-3 mb-4 flex-1">
          {post.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {post.tags.map(tag => (
            <span key={tag} className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tight text-slate-500 bg-white/5 border border-white/10 px-2 py-0.5 rounded-md">
              <Tag className="w-3 h-3" />
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
          <div className="flex items-center gap-4">
            <button 
              id={`comment-trigger-${post.id}`}
              onClick={() => setShowComments(!showComments)}
              className={cn(
                "flex items-center gap-1.5 transition-colors text-xs font-semibold px-3 py-1.5 rounded-lg",
                showComments ? "bg-indigo-600/10 text-indigo-400" : "text-slate-400 hover:text-indigo-400 hover:bg-white/5"
              )}
            >
              <MessageCircle className="w-4 h-4" />
              Discussion
            </button>
            <button 
              id={`like-trigger-${post.id}`}
              onClick={handleLikeToggle}
              className={cn(
                "flex items-center gap-1.5 transition-all text-xs font-semibold px-3 py-1.5 rounded-lg",
                hasLiked ? "text-pink-500 bg-pink-500/10" : "text-slate-400 hover:text-pink-500 hover:bg-white/5 animate-pulse"
              )}
            >
              <Heart className={cn("w-4 h-4", hasLiked ? "fill-pink-500" : "")} />
              {likesCount}
            </button>
          </div>
          
          <button 
            onClick={() => onDealClick(post)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/20 active:scale-95"
          >
            Get Deal
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        {/* Real-time Expandable Comments Section */}
        <AnimatePresence>
          {showComments && (
            <motion.div
              id={`comments-panel-${post.id}`}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mt-6 pt-6 border-t border-white/5"
            >
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-4 flex items-center justify-between">
                <span>Discussion ({comments.length})</span>
                <span className="text-[10px] text-indigo-400 font-normal normal-case">Real-time synced</span>
              </h4>

              {/* Comments Feed List */}
              <div className="space-y-4 max-h-56 overflow-y-auto pr-1 mb-4 no-scrollbar">
                {comments.length === 0 ? (
                  <p className="text-xs text-slate-600 italic text-center py-4">No comments yet. Start the conversation!</p>
                ) : (
                  comments.map(c => {
                    const isAuthor = currentUser?.uid === c.userId;
                    const isPostOwner = currentUser?.uid === post.userId;
                    return (
                      <div key={c.id} className="flex gap-3 bg-white/[0.02] p-3 rounded-2xl border border-white/5 flex-col relative group/comment">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <img src={c.user?.photoURL || 'https://ui-avatars.com/api/?name=U'} alt="" className="w-5 h-5 rounded-full" />
                            <span className="text-xs font-bold text-slate-300">{c.user?.displayName || 'Anonymous'}</span>
                            <span className="text-[8px] text-slate-600">{formatDistanceToNow(new Date(c.createdAt))} ago</span>
                          </div>
                          {(isAuthor || isPostOwner) && (
                            <button 
                              onClick={() => handleDeleteComment(c.id)}
                              className="text-slate-600 hover:text-red-400 transition-colors p-1"
                              title="Delete comment"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-slate-4/100 pl-7 text-slate-300 break-words leading-relaxed">{c.text}</p>
                      </div>
                    );
                  })
                )}
              </div>

              {/* New Comment Input form */}
              {currentUser ? (
                <form onSubmit={handleAddComment} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Add an opinion or feedback..."
                    className="flex-1 bg-white/5 text-xs text-slate-200 border border-white/10 rounded-xl py-2.5 px-4 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:bg-white/10 placeholder:text-slate-600 transition-all font-medium"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    required
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingComment || !newComment.trim()}
                    className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white p-2.5 rounded-xl transition-all self-end cursor-pointer flex items-center justify-center shadow-md hover:shadow-indigo-500/20"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <div className="text-center p-3 rounded-xl bg-indigo-500/5 border border-indigo-500/10">
                  <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Please sign in to join the conversation.</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
