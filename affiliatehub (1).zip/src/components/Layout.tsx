import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Plus, LogOut, TrendingUp, X, Mail, Lock, User as UserIcon } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { cn as clsx } from '../lib/utils';

interface LayoutProps {
  children: React.ReactNode;
  onSearch?: (term: string) => void;
}

export default function Layout({ children, onSearch }: LayoutProps) {
  const [user, setUser] = useState(auth.currentUser);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [authError, setAuthError] = useState('');
  const [showWelcomePopup, setShowWelcomePopup] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        let avatarUrl = u.photoURL;
        if (!avatarUrl) {
          avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(u.displayName || 'User')}&background=6366f1&color=fff&bold=true&size=128`;
          try {
            await updateProfile(u, { photoURL: avatarUrl });
          } catch (e) {
            console.warn('Could not update Auth photoURL:', e);
          }
        }

        const path = `users/${u.uid}`;
        try {
          const userRef = doc(db, 'users', u.uid);
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            await setDoc(userRef, {
              uid: u.uid,
              email: u.email,
              displayName: u.displayName || 'Marketer',
              photoURL: avatarUrl,
              createdAt: new Date().toISOString()
            });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, path);
        }
      }
    });
  }, []);

  const handleGoogleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      setShowAuthModal(false);
      setShowWelcomePopup(true);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      if (authMode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        const placeholderName = displayName || email.split('@')[0];
        const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(placeholderName)}&background=6366f1&color=fff&bold=true&size=128`;
        await updateProfile(cred.user, { 
          displayName: placeholderName,
          photoURL: avatarUrl
        });
        
        // Write instantly to FireStore to avoid race conditions
        const userRef = doc(db, 'users', cred.user.uid);
        await setDoc(userRef, {
          uid: cred.user.uid,
          email: cred.user.email,
          displayName: placeholderName,
          photoURL: avatarUrl,
          createdAt: new Date().toISOString()
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      setShowAuthModal(false);
      setShowWelcomePopup(true);
    } catch (error: any) {
      console.error('Email authentication error:', error);
      let message = error.message;
      
      if (error.code === 'auth/invalid-credential') {
        if (authMode === 'login') {
          message = 'Incorrect email or password. Please verify your credentials and try again.';
        } else {
          message = 'Failed to create account. Make sure the Email/Password provider is enabled in your Firebase Console (Authentication > Sign-in method).';
        }
      } else if (error.code === 'auth/email-already-in-use') {
        message = 'This email address is already in use by another account.';
      } else if (error.code === 'auth/weak-password') {
        message = 'Password is too weak. The password must be at least 6 characters.';
      } else if (error.code === 'auth/invalid-email') {
        message = 'Invalid email address format.';
      } else if (error.code === 'auth/operation-not-allowed') {
        message = 'Email/Password sign-in is not enabled. Please enable it in your Firebase Authentication Console.';
      }
      
      setAuthError(message);
    }
  };

  const handleLogout = () => {
    signOut(auth);
    navigate('/');
  };

  return (
    <div id="main-layout-container" className="min-h-screen relative overflow-hidden bg-brand-bg">
      {/* Background Orbs */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-900/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Navbar */}
      <nav id="navbar-container" className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-white/5 bg-brand-bg/50 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between">
        <Link id="brand-logo-link" to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <TrendingUp className="text-white w-6 h-6" />
          </div>
          <span id="brand-logo-text" className="font-display font-bold text-xl tracking-tight hidden sm:block">Affolo</span>
        </Link>

        {/* Search Bar */}
        <div id="global-search-container" className={clsx(
          "relative flex-1 max-w-md mx-4 transition-all duration-300",
          isSearchFocused ? "max-w-lg" : "max-w-md"
        )}>
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="global-search-input"
            type="text"
            placeholder="Search affiliate products..."
            className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all placeholder:text-slate-500"
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            onChange={(e) => onSearch?.(e.target.value)}
          />
        </div>

        <div id="navbar-actions" className="flex items-center gap-2 sm:gap-4">
          {user && (
            <Link id="navbar-create-button" to="/create" className="glass-button p-2 sm:px-4 sm:py-2 rounded-full flex items-center gap-2 text-sm font-medium">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Create</span>
            </Link>
          )}

          {user ? (
            <div id="logged-in-user-menu" className="flex items-center gap-3 pl-2 sm:pl-4 border-l border-white/10">
              <Link id="navbar-profile-avatar-link" to="/profile" className="w-9 h-9 rounded-full border border-white/20 overflow-hidden hover:ring-2 ring-indigo-500/50 transition-all">
                <img id="navbar-profile-avatar-img" src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName || 'U'}&background=random`} alt={user.displayName || ''} className="w-full h-full object-cover" />
              </Link>
              <button 
                id="navbar-logout-button"
                onClick={handleLogout}
                className="p-2 hover:bg-white/5 rounded-full text-slate-400 hover:text-white transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button 
              id="navbar-signin-button"
              onClick={() => setShowAuthModal(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-full text-sm font-semibold transition-all hover:shadow-lg hover:shadow-indigo-500/20 active:scale-95"
            >
              Sign In
            </button>
          )}
        </div>
      </nav>

      {/* Auth Modal */}
      <AnimatePresence>
        {showAuthModal && (
          <div id="auth-modal-overlay" className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              id="auth-modal-card"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="glass-card w-full max-w-md p-8 relative overflow-hidden"
            >
              <button 
                id="auth-modal-close-button"
                onClick={() => setShowAuthModal(false)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div id="auth-modal-header" className="text-center mb-8">
                <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-indigo-500/20">
                  <TrendingUp className="text-white w-8 h-8" />
                </div>
                <h2 id="auth-modal-title" className="text-2xl font-display font-bold">{authMode === 'login' ? 'Welcome Back' : 'Create Account'}</h2>
                <p id="auth-modal-subtitle" className="text-slate-400 text-sm">{authMode === 'login' ? 'Sign in to manage your empire' : 'Join thousands of marketers'}</p>
              </div>

              <form id="auth-modal-form" onSubmit={handleEmailAuth} className="space-y-4">
                {authMode === 'signup' && (
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      id="auth-displayname-input"
                      type="text"
                      placeholder="Display Name"
                      required
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                    />
                  </div>
                )}
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="auth-email-input"
                    type="email"
                    placeholder="Email Address"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    id="auth-password-input"
                    type="password"
                    placeholder="Password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>

                {authError && <p id="auth-modal-error-text" className="text-red-400 text-xs text-center">{authError}</p>}

                <button id="auth-submit-button" type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20 active:scale-[0.98]">
                  {authMode === 'login' ? 'Sign In' : 'Sign Up'}
                </button>
              </form>

              <div className="my-6 flex items-center gap-4 text-slate-600 text-xs font-bold uppercase tracking-widest">
                <div className="flex-1 h-[1px] bg-white/5" />
                OR
                <div className="flex-1 h-[1px] bg-white/5" />
              </div>

              <button 
                id="auth-modal-google-button"
                onClick={handleGoogleLogin}
                className="w-full glass-button py-3 rounded-xl flex items-center justify-center gap-3 font-semibold mb-6"
              >
                <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="" />
                Continue with Google
              </button>

              <p className="text-center text-slate-400 text-sm">
                {authMode === 'login' ? "Don't have an account?" : "Already a member?"}{' '}
                <button 
                  id="auth-modal-toggle-button"
                  onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}
                  className="text-indigo-400 font-bold hover:underline"
                >
                  {authMode === 'login' ? 'Sign Up' : 'Sign In'}
                </button>
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Welcome Pop-up */}
      <AnimatePresence>
        {showWelcomePopup && (
          <div id="welcome-modal-overlay" className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
            <motion.div
              id="welcome-modal-card"
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="glass-card w-full max-w-md p-8 relative overflow-hidden text-center border-indigo-500/30"
            >
              {/* Premium Glow effect */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-indigo-500/20 blur-[60px] rounded-full pointer-events-none" />

              <div className="w-20 h-20 bg-gradient-to-tr from-indigo-600 to-violet-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-indigo-500/30 ring-1 ring-white/20 animate-pulse">
                <span className="text-3xl">🚀</span>
              </div>

              <h2 id="welcome-popup-title" className="text-2xl font-display font-black tracking-tight mb-3 text-white">
                Welcome to Affolo!
              </h2>

              <p id="welcome-popup-message" className="text-slate-300 text-sm leading-relaxed mb-8">
                Yaha aap apni affiliate Product ko <span className="text-indigo-400 font-semibold underline decoration-2 decoration-indigo-500/40">sell per rakh sakte hai</span> aur pure global markets me share kar ke traffic earn kar sakte hain.
              </p>

              <button 
                id="welcome-thanks-button"
                onClick={() => setShowWelcomePopup(false)}
                className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold py-3.5 px-6 rounded-xl transition-all shadow-lg shadow-indigo-500/25 active:scale-95 text-sm uppercase tracking-wider"
              >
                Thanks
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <main id="main-content" className="pt-24 pb-12 px-4 sm:px-6 max-w-7xl mx-auto relative z-10">
        {children}
      </main>
    </div>
  );
}

