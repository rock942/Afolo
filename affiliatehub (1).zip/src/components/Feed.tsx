import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, onSnapshot, doc, updateDoc, increment, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Post } from '../types';
import { Calendar, Filter, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import PostCard from './PostCard';

interface FeedProps {
  searchTerm: string;
}

export default function Feed({ searchTerm }: FeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'clicks' | 'likes'>('newest');
  const [isSortOpen, setIsSortOpen] = useState(false);

  useEffect(() => {
    const path = 'posts';
    const q = query(collection(db, path), limit(100));
    
    return onSnapshot(q, (snapshot) => {
      const postsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Post[];
      
      // Sort in-memory to avoid index requirement
      postsData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      
      setPosts(postsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
      setLoading(false);
    });
  }, []);

  const handleDealClick = async (post: Post) => {
    const postPath = `posts/${post.id}`;
    const clickPath = `posts/${post.id}/clicks`;
    
    try {
      const postRef = doc(db, 'posts', post.id);
      await updateDoc(postRef, {
        clicks: increment(1),
        updatedAt: new Date().toISOString()
      });
      
      await addDoc(collection(db, clickPath), {
        postId: post.id,
        timestamp: new Date().toISOString(),
        referrer: window.location.href
      });

      window.open(post.originalUrl, '_blank');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, postPath);
      window.open(post.originalUrl, '_blank');
    }
  };

  const allTags = Array.from(new Set(posts.flatMap(p => p.tags || []))).slice(0, 15);

  const filteredPosts = posts.filter(post => {
    const matchesSearch = !searchTerm || 
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTag = !activeTag || (post.tags && post.tags.includes(activeTag));
    
    const postDate = new Date(post.createdAt);
    const now = new Date();
    let matchesDate = true;

    if (dateFilter === 'today') {
      matchesDate = postDate.toDateString() === now.toDateString();
    } else if (dateFilter === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(now.getDate() - 7);
      matchesDate = postDate >= weekAgo;
    } else if (dateFilter === 'month') {
      const monthAgo = new Date();
      monthAgo.setMonth(now.getMonth() - 1);
      matchesDate = postDate >= monthAgo;
    }

    return matchesSearch && matchesTag && matchesDate;
  });

  const sortedPosts = [...filteredPosts].sort((a, b) => {
    if (sortBy === 'clicks') {
      return (b.clicks || 0) - (a.clicks || 0);
    }
    if (sortBy === 'likes') {
      return (b.likesCount || 0) - (a.likesCount || 0);
    }
    // Default to 'newest'
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="w-16 h-16 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin" />
        <p className="mt-6 text-slate-500 font-bold uppercase tracking-widest text-[10px]">Scanning Global Markets</p>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Dynamic Filter Section */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 pb-8 border-b border-white/5">
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1">
          <button
            onClick={() => setActiveTag(null)}
            className={cn(
              "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap",
              !activeTag ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" : "bg-white/5 text-slate-500 hover:text-slate-300"
            )}
          >
            All Sectors
          </button>
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setActiveTag(tag)}
              className={cn(
                "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border",
                activeTag === tag ? "bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-600/20" : "bg-transparent border-white/5 text-slate-500 hover:text-slate-300 hover:border-white/10"
              )}
            >
              #{tag}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {/* Sorting Dropdown */}
          <div className="relative z-40">
            <button
              id="custom-sort-dropdown-trigger"
              onClick={() => setIsSortOpen(!isSortOpen)}
              className="flex items-center gap-2 bg-white/5 border border-white/10 hover:border-indigo-500/30 active:scale-95 px-4 py-2.5 rounded-xl transition-all cursor-pointer"
            >
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
                Sort:
              </span>
              <span className="text-[10px] uppercase font-black text-slate-200">
                {sortBy === 'newest' && 'Newest'}
                {sortBy === 'clicks' && 'Most Clicked'}
                {sortBy === 'likes' && 'Highest Likes'}
              </span>
              <ChevronDown className={cn("w-3.5 h-3.5 text-slate-400 transition-transform duration-300", isSortOpen && "rotate-180")} />
            </button>

            <AnimatePresence>
              {isSortOpen && (
                <>
                  {/* Invisible backdrop to dismiss dropdown on click outside */}
                  <div 
                    className="fixed inset-0 z-40 cursor-default" 
                    onClick={() => setIsSortOpen(false)} 
                  />
                  <motion.div
                    id="custom-sort-dropdown-menu"
                    initial={{ opacity: 0, scale: 0.95, y: -8 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -8 }}
                    transition={{ duration: 0.15, ease: 'easeOut' }}
                    className="absolute right-0 mt-2 w-48 bg-[#0b0f19]/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl z-50 p-1.5 space-y-1"
                  >
                    {[
                      { value: 'newest', label: 'Newest Releases' },
                      { value: 'clicks', label: 'Most Clicked' },
                      { value: 'likes', label: 'Highest Likes' }
                    ].map((opt) => (
                      <button
                        key={opt.value}
                        onClick={() => {
                          setSortBy(opt.value as any);
                          setIsSortOpen(false);
                        }}
                        className={cn(
                          "w-full text-left px-3 py-2.5 rounded-xl text-[10px] uppercase font-black tracking-wider transition-all flex items-center justify-between cursor-pointer",
                          sortBy === opt.value
                            ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/25"
                            : "text-slate-400 hover:text-indigo-400 hover:bg-white/5"
                        )}
                      >
                        {opt.label}
                        {sortBy === opt.value && (
                          <span className="w-1.5 h-1.5 bg-white rounded-full" />
                        )}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          {/* Date Filter */}
          <div className="flex items-center bg-white/5 p-1 rounded-xl border border-white/10">
            <div className="px-3 text-slate-400">
               <Calendar className="w-3 h-3 text-indigo-400" />
            </div>
            {[
              { id: 'all', label: 'All Time' },
              { id: 'today', label: 'Today' },
              { id: 'week', label: 'Week' },
              { id: 'month', label: 'Month' }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setDateFilter(f.id as any)}
                className={cn(
                  "px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-tighter transition-all",
                  dateFilter === f.id ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20" : "text-slate-500 hover:text-slate-300"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {sortedPosts.length === 0 ? (
        <div className="py-24 text-center glass-card border-dashed">
           <Filter className="w-12 h-12 text-slate-800 mx-auto mb-4" />
           <h4 className="text-xl font-display font-bold mb-2">No results found</h4>
           <p className="text-slate-500 mb-6">Adjust your filters to discover more opportunities.</p>
           <button 
             onClick={() => { setActiveTag(null); setDateFilter('all'); setSortBy('newest'); }}
             className="text-indigo-400 font-bold hover:underline"
           >
             Reset all filters
           </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sortedPosts.map((post) => (
            <PostCard 
              key={post.id}
              post={post}
              onDealClick={handleDealClick}
            />
          ))}
        </div>
      )}
    </div>
  );
}
