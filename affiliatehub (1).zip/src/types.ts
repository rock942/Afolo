export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt: string;
}

export interface Post {
  id: string;
  userId: string;
  title: string;
  description: string;
  tags: string[];
  originalUrl: string;
  imageUrl: string;
  clicks: number;
  likesCount: number;
  createdAt: string;
  updatedAt: string;
  user?: {
    displayName: string;
    photoURL: string;
  };
}

export interface ClickRecord {
  postId: string;
  timestamp: string;
  referrer: string;
}
