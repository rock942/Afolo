# AffiliateHub Security Specification

## Data Invariants
1. A **User** document must match the authenticating user (uid match).
2. A **Post** must be owned by the user who created it (`userId`).
3. **Clicks** are immutable and belong to a specific `postId`.
4. Users cannot modify `clicks` counts or `updatedAt` timestamps arbitrarily without following the strict update schema.

## The Dirty Dozen (Attack Payloads)
1. Creating a Post with someone else's `userId`.
2. Updating a Post's `userId` to take ownership of someone else's post.
3. Injecting a 1MB string into the `tags` array.
4. Setting `clicks` to 1,000,000 on creation.
5. Deleting someone else's Post.
6. Reading another user's PII in the `users` collection.
7. Updating a Post but changing the `createdAt` timestamp.
8. Adding a tag that is not a string.
9. Creating a click with a future timestamp.
10. Querying all Posts with a blanket `isSignedIn()` rule (Scraping).
11. Setting a Post's ID as a 2KB junk string.
12. Updating a Post title to 10,000 characters.

## Security Controls
- Standard `isValidId` helper.
- `isValidPost` and `isValidUser` schemas.
- `isOwner` check for updates/deletes.
- `affectedKeys().hasOnly()` for granular updates.
- Server timestamp validation.
